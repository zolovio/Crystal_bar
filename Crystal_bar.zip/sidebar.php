        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Menu</li>
                        <li id="index">
                            <a href="index"><i class="fas fa-chart-pie"></i><span class="side-txt">Dashboard</span></a>
                        </li>
                        <li class="submenu" id="creat-bill">
                            <a href="#"><i class="fa fa-calculator" aria-hidden="true"></i><span class="side-txt">Billing</span> <span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="creat-bill" id="cb" class="cv">Creat Bill</a></li>
                                <li><a href="view-sattlment">View Settlement</a></li>
                                <li><a href="view-bill">View Bill</a></li>
                               
                            </ul>
                        </li>
                        <li class="submenu" id="manage-inventry">
                            <a href="#"><i class="fa fa-cogs" aria-hidden="true"></i><span class="side-txt">Inventory Management</span> <span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="manage-inventry">Manage Inventory</a></li>
                                <li><a href="add-product">Add Product</a></li>
                            
                               
                            </ul>
                        </li>
                        
                        
                    </ul>
                </div>
            </div>
        </div>